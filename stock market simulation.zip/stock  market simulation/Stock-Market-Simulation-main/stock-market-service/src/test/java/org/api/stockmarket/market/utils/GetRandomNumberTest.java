package org.api.stockmarket.market.utils;

import org.junit.jupiter.api.Test;
import org.api.stockmarket.market.utils.GetRandomNumberTest;
import org.api.stockmarket.stocks.stock.enums.MarketCap;

import static org.junit.jupiter.api.Assertions.*;

class GetRandomNumberTest {

    @Test
    void randomNumberShouldBeWithinBounds() {
        double randomLargeCapNumber = GetRandomNumberTest.getRandomNumberForStocks(MarketCap.Large);
        double randomMidCapNumber = GetRandomNumberTest.getRandomNumberForStocks(MarketCap.Mid);
        double randomSmallCapNumber = GetRandomNumberTest.getRandomNumberForStocks(MarketCap.Small);

        assert (randomLargeCapNumber > -.002 && randomLargeCapNumber < .002);
        assert (randomMidCapNumber > -.001 && randomMidCapNumber < .001);
        assert (randomSmallCapNumber > -.003 && randomSmallCapNumber < .003);
        assertThrows(IllegalArgumentException.class,
                () -> GetRandomNumberTest.getRandomNumberForStocks(MarketCap.valueOf("")));
    }

    private static double getRandomNumberForStocks(MarketCap large) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getRandomNumberForStocks'");
    }

    @Test
    void randomPositiveNumbersShouldBeWithinBounds() {
        double randomLargeCapNumber = GetRandomNumberTest.getRandomPositiveNumberForStocks(MarketCap.Large);
        double randomMidCapNumber = GetRandomNumberTest.getRandomPositiveNumberForStocks(MarketCap.Mid);
        double randomSmallCapNumber = GetRandomNumberTest.getRandomPositiveNumberForStocks(MarketCap.Small);

        assert (randomLargeCapNumber > 0 && randomLargeCapNumber < .002);
        assert (randomMidCapNumber > 0 && randomMidCapNumber < .001);
        assert (randomSmallCapNumber > 0 && randomSmallCapNumber < .003);
    }

    private static double getRandomPositiveNumberForStocks(MarketCap large) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getRandomPositiveNumberForStocks'");
    }

}