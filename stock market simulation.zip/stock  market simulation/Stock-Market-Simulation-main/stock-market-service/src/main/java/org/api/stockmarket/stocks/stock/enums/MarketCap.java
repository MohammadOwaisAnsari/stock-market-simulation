package org.api.stockmarket.stocks.stock.enums;

public enum MarketCap {
    Small,
    Mid,
    Large
}
