package org.api.stockmarket.stocks.stock.enums;

public enum Volatility {
    STABLE,
    NORMAL,
    VOLATILE,
    EXTRA_VOLATILE
}
