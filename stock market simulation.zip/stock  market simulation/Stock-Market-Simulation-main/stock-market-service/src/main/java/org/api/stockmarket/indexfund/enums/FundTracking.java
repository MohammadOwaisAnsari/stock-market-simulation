package org.api.stockmarket.indexfund.enums;

public enum FundTracking {
    TOTAL_MARKET,
    MARKET_CAP,
    SECTOR,
    VOLATILITY
}
